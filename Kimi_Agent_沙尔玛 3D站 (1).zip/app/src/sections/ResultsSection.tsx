import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Trophy, TrendingUp, Users, Award, Target, BookOpen } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const results = [
  {
    id: 1,
    title: 'Top Ranks',
    description: 'Consistent top 100 ranks in competitive exams',
    icon: Trophy,
    stat: '500+',
    label: 'Top Rankers',
  },
  {
    id: 2,
    title: 'Consistent Results',
    description: '95%+ success rate year after year',
    icon: TrendingUp,
    stat: '95%',
    label: 'Success Rate',
  },
  {
    id: 3,
    title: 'Alumni Network',
    description: 'Strong network of successful graduates',
    icon: Users,
    stat: '10K+',
    label: 'Alumni',
  },
];

const achievements = [
  { icon: Award, label: 'Best Coaching Institute 2023' },
  { icon: Target, label: '100% Results in XII Board' },
  { icon: BookOpen, label: '25+ Years of Excellence' },
];

const ResultsSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const ribbonRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        panelRef.current,
        { scale: 0.94, opacity: 0 },
        { scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        ribbonRef.current,
        { x: '-12vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.05
      );

      scrollTl.fromTo(
        contentRef.current?.querySelectorAll('.animate-item') || [],
        { y: '6vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none', stagger: 0.03 },
        0.08
      );

      scrollTl.fromTo(
        cardsRef.current?.querySelectorAll('.result-card') || [],
        { x: '18vw', rotateY: -24, opacity: 0 },
        { x: 0, rotateY: -12, opacity: 1, ease: 'none', stagger: 0.05 },
        0.1
      );

      // SETTLE (30%-70%): Hold

      // EXIT (70%-100%)
      scrollTl.fromTo(
        contentRef.current?.querySelectorAll('.animate-item') || [],
        { x: 0, opacity: 1 },
        { x: '-14vw', opacity: 0, ease: 'power2.in', stagger: 0.02 },
        0.7
      );

      scrollTl.fromTo(
        cardsRef.current?.querySelectorAll('.result-card') || [],
        { x: 0, rotateY: -12, opacity: 1 },
        { x: '16vw', rotateY: -24, opacity: 0, ease: 'power2.in', stagger: 0.03 },
        0.7
      );

      scrollTl.fromTo(
        ribbonRef.current,
        { y: 0, opacity: 1 },
        { y: '-8vh', opacity: 0, ease: 'power2.in' },
        0.75
      );

      scrollTl.fromTo(
        panelRef.current,
        { scale: 1, opacity: 1 },
        { scale: 1.05, opacity: 0, ease: 'power2.in' },
        0.78
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="results"
      ref={sectionRef}
      className="section-pinned bg-[#0B0F1C] flex items-center justify-center"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/results_bg.jpg"
          alt="Results"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 dark-overlay" />
      </div>

      {/* Blue Stage Panel */}
      <div
        ref={panelRef}
        className="absolute left-[6vw] top-[12vh] w-[88vw] h-[76vh] blue-stage rounded-[34px] opacity-0"
      />

      {/* Red Ribbon */}
      <div
        ref={ribbonRef}
        className="absolute left-[10vw] top-[6vh] w-[26vw] min-w-[180px] h-[10vh] min-h-[60px] red-ribbon rounded-[14px] flex items-center px-6 opacity-0 z-10"
      >
        <span className="text-white font-semibold text-sm uppercase tracking-[0.18em]">
          Results
        </span>
      </div>

      {/* Content Container */}
      <div className="absolute inset-0 flex items-center">
        {/* Left Content */}
        <div ref={contentRef} className="w-full lg:w-1/2 px-[11vw] z-10">
          <h2 className="animate-item section-title font-extrabold text-white mb-4 opacity-0">
            Proven <span className="text-gradient">Results</span>
          </h2>

          <p className="animate-item text-[#B8C0E0] text-lg max-w-md mb-6 opacity-0">
            Year after year, our students secure top ranks and admissions in premier colleges.
          </p>

          {/* Achievement Tags */}
          <div className="animate-item flex flex-wrap gap-2 mb-6 opacity-0">
            {achievements.map((achievement, index) => {
              const Icon = achievement.icon;
              return (
                <span
                  key={index}
                  className="px-3 py-2 bg-white/10 rounded-lg text-white/90 text-sm flex items-center gap-2 border border-white/10"
                >
                  <Icon className="w-4 h-4 text-[#E11D2E]" />
                  {achievement.label}
                </span>
              );
            })}
          </div>

          <button
            onClick={() => scrollToSection('admissions')}
            className="animate-item btn-primary flex items-center gap-2 opacity-0"
          >
            Join the Next Batch
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Right Content - Result Cards */}
        <div
          ref={cardsRef}
          className="hidden lg:block w-1/2 h-full relative card-stage"
        >
          <div className="absolute left-[4vw] top-[16vh] w-[42vw] h-[64vh] preserve-3d">
            <div className="grid grid-cols-3 gap-4 h-full">
              {results.map((result, index) => {
                const Icon = result.icon;
                const floatClass = index === 0 
                  ? 'animate-float' 
                  : index === 1 
                    ? 'animate-float-delayed' 
                    : 'animate-float-delayed-2';
                
                return (
                  <div
                    key={result.id}
                    className={`result-card bg-[#0B0F1C]/70 backdrop-blur-sm rounded-[22px] border border-white/10 p-5 card-shadow opacity-0 cursor-pointer group hover:bg-[#0B0F1C]/90 transition-all duration-300 ${floatClass}`}
                    style={{ transformStyle: 'preserve-3d' }}
                  >
                    <div className="w-12 h-12 bg-[#E11D2E]/20 rounded-xl flex items-center justify-center mb-4 group-hover:bg-[#E11D2E]/30 transition-colors">
                      <Icon className="w-6 h-6 text-[#E11D2E]" />
                    </div>
                    
                    <div className="mb-3">
                      <span className="text-3xl font-extrabold text-white">{result.stat}</span>
                    </div>
                    
                    <h3 className="text-white font-bold text-lg mb-2">{result.title}</h3>
                    <p className="text-[#B8C0E0] text-sm">{result.description}</p>
                    
                    <div className="mt-4 pt-4 border-t border-white/10">
                      <span className="text-[#E11D2E] text-xs font-medium uppercase tracking-wider">
                        {result.label}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Mobile Cards */}
        <div className="lg:hidden absolute bottom-8 left-0 right-0 px-6">
          <div className="flex gap-3 overflow-x-auto pb-4">
            {results.map((result) => {
              const Icon = result.icon;
              return (
                <div
                  key={result.id}
                  className="flex-shrink-0 w-48 bg-[#0B0F1C]/80 backdrop-blur-sm rounded-[16px] border border-white/10 p-4 card-shadow"
                >
                  <div className="w-10 h-10 bg-[#E11D2E]/20 rounded-lg flex items-center justify-center mb-3">
                    <Icon className="w-5 h-5 text-[#E11D2E]" />
                  </div>
                  <div className="mb-2">
                    <span className="text-2xl font-extrabold text-white">{result.stat}</span>
                  </div>
                  <h3 className="text-white font-bold text-sm mb-1">{result.title}</h3>
                  <p className="text-[#B8C0E0] text-xs">{result.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ResultsSection;
