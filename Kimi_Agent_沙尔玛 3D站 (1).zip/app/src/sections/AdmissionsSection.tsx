import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Phone, Mail, User, BookOpen, MessageSquare, Send } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

gsap.registerPlugin(ScrollTrigger);

const admissionTypes = [
  { id: 'open_school', label: 'Open School' },
  { id: 'jbt', label: 'JBT' },
  { id: 'bed', label: 'B.Ed.' },
];

const AdmissionsSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const ribbonRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLDivElement>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    course: '',
    message: '',
  });
  const [showDialog, setShowDialog] = useState(false);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        panelRef.current,
        { scale: 0.94, opacity: 0 },
        { scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        ribbonRef.current,
        { x: '-12vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.05
      );

      scrollTl.fromTo(
        contentRef.current?.querySelectorAll('.animate-item') || [],
        { y: '6vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none', stagger: 0.03 },
        0.08
      );

      scrollTl.fromTo(
        formRef.current,
        { x: '18vw', rotateY: -22, opacity: 0 },
        { x: 0, rotateY: -10, opacity: 1, ease: 'none' },
        0.1
      );

      // SETTLE (30%-70%): Hold

      // EXIT (70%-100%)
      scrollTl.fromTo(
        contentRef.current?.querySelectorAll('.animate-item') || [],
        { x: 0, opacity: 1 },
        { x: '-14vw', opacity: 0, ease: 'power2.in', stagger: 0.02 },
        0.7
      );

      scrollTl.fromTo(
        formRef.current,
        { x: 0, rotateY: -10, opacity: 1 },
        { x: '16vw', rotateY: -22, opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        ribbonRef.current,
        { y: 0, opacity: 1 },
        { y: '-8vh', opacity: 0, ease: 'power2.in' },
        0.75
      );

      scrollTl.fromTo(
        panelRef.current,
        { scale: 1, opacity: 1 },
        { scale: 1.05, opacity: 0, ease: 'power2.in' },
        0.78
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowDialog(true);
    setFormData({ name: '', email: '', phone: '', course: '', message: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="admissions"
      ref={sectionRef}
      className="section-pinned bg-[#0B0F1C] flex items-center justify-center"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/admissions_bg.jpg"
          alt="Admissions"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 dark-overlay" />
      </div>

      {/* Blue Stage Panel */}
      <div
        ref={panelRef}
        className="absolute left-[6vw] top-[12vh] w-[88vw] h-[76vh] blue-stage rounded-[34px] opacity-0"
      />

      {/* Red Ribbon */}
      <div
        ref={ribbonRef}
        className="absolute left-[10vw] top-[6vh] w-[30vw] min-w-[200px] h-[10vh] min-h-[60px] red-ribbon rounded-[14px] flex items-center px-6 opacity-0 z-10"
      >
        <span className="text-white font-semibold text-sm uppercase tracking-[0.18em]">
          Admissions
        </span>
      </div>

      {/* Content Container */}
      <div className="absolute inset-0 flex items-center">
        {/* Left Content */}
        <div ref={contentRef} className="w-full lg:w-1/2 px-[11vw] z-10">
          <h2 className="animate-item section-title font-extrabold text-white mb-4 opacity-0">
            Admissions <span className="text-gradient">Open</span>
          </h2>

          <p className="animate-item text-[#B8C0E0] text-lg max-w-md mb-6 opacity-0">
            Join Open School, JBT, or B.Ed. pathways. Fill the form and we'll guide your next step.
          </p>

          {/* Admission Types */}
          <div className="animate-item flex flex-wrap gap-3 mb-6 opacity-0">
            {admissionTypes.map((type) => (
              <span
                key={type.id}
                className="px-4 py-2 bg-[#E11D2E]/20 border border-[#E11D2E]/40 rounded-lg text-white font-medium text-sm"
              >
                {type.label}
              </span>
            ))}
          </div>

          <button
            onClick={() => scrollToSection('contact')}
            className="animate-item btn-primary flex items-center gap-2 opacity-0"
          >
            <Phone className="w-4 h-4" />
            Request a Callback
          </button>
        </div>

        {/* Right Content - Form Card */}
        <div
          ref={formRef}
          className="hidden lg:block w-1/2 h-full relative card-stage"
        >
          <div className="absolute left-[6vw] top-[16vh] w-[38vw] h-[64vh] preserve-3d">
            <div 
              className="w-full h-full bg-[#0B0F1C]/80 backdrop-blur-md rounded-[22px] border border-white/10 p-6 card-shadow overflow-y-auto"
              style={{ transformStyle: 'preserve-3d' }}
            >
              <h3 className="text-white font-bold text-xl mb-4 flex items-center gap-2">
                <Send className="w-5 h-5 text-[#E11D2E]" />
                Submit Inquiry
              </h3>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-[#B8C0E0] text-sm mb-1.5 flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Full Name
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg text-white placeholder-white/40 focus:ring-2 focus:ring-[#E11D2E]/50 focus:border-[#E11D2E] transition-all"
                    placeholder="Enter your name"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[#B8C0E0] text-sm mb-1.5 flex items-center gap-2">
                      <Mail className="w-4 h-4" />
                      Email
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg text-white placeholder-white/40 focus:ring-2 focus:ring-[#E11D2E]/50 focus:border-[#E11D2E] transition-all"
                      placeholder="your@email.com"
                    />
                  </div>
                  <div>
                    <label className="text-[#B8C0E0] text-sm mb-1.5 flex items-center gap-2">
                      <Phone className="w-4 h-4" />
                      Phone
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg text-white placeholder-white/40 focus:ring-2 focus:ring-[#E11D2E]/50 focus:border-[#E11D2E] transition-all"
                      placeholder="+91XXXXXXXXXX"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[#B8C0E0] text-sm mb-1.5 flex items-center gap-2">
                    <BookOpen className="w-4 h-4" />
                    Course Interest
                  </label>
                  <select
                    name="course"
                    value={formData.course}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#E11D2E]/50 focus:border-[#E11D2E] transition-all appearance-none cursor-pointer"
                  >
                    <option value="" className="bg-[#0B0F1C]">Select a course</option>
                    <option value="xi_xii" className="bg-[#0B0F1C]">XI-XII Coaching</option>
                    <option value="ba_bcom" className="bg-[#0B0F1C]">B.A., B.Com</option>
                    <option value="medical" className="bg-[#0B0F1C]">Medical Entrance</option>
                    <option value="engineering" className="bg-[#0B0F1C]">Engineering Entrance</option>
                    <option value="law" className="bg-[#0B0F1C]">Law Entrance</option>
                    <option value="open_school" className="bg-[#0B0F1C]">Open School</option>
                    <option value="jbt" className="bg-[#0B0F1C]">JBT</option>
                    <option value="bed" className="bg-[#0B0F1C]">B.Ed.</option>
                  </select>
                </div>

                <div>
                  <label className="text-[#B8C0E0] text-sm mb-1.5 flex items-center gap-2">
                    <MessageSquare className="w-4 h-4" />
                    Message
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={3}
                    className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg text-white placeholder-white/40 focus:ring-2 focus:ring-[#E11D2E]/50 focus:border-[#E11D2E] transition-all resize-none"
                    placeholder="Any questions or specific requirements..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full btn-primary flex items-center justify-center gap-2 mt-2"
                >
                  <Send className="w-4 h-4" />
                  Submit Inquiry
                </button>
              </form>
            </div>
          </div>
        </div>

        {/* Mobile CTA */}
        <div className="lg:hidden absolute bottom-8 left-0 right-0 px-6">
          <button
            onClick={() => scrollToSection('contact')}
            className="w-full btn-primary flex items-center justify-center gap-2"
          >
            <ArrowRight className="w-4 h-4" />
            Fill Inquiry Form
          </button>
        </div>
      </div>

      {/* Success Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="bg-[#0B0F1C] border-white/10 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-[#E11D2E]">
              Inquiry Submitted!
            </DialogTitle>
            <DialogDescription className="text-[#B8C0E0]">
              Thank you for your interest. Our team will contact you within 24 hours.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4">
            <button
              onClick={() => setShowDialog(false)}
              className="w-full btn-primary"
            >
              Close
            </button>
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default AdmissionsSection;
