import { useEffect, useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Phone } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const HeroSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const ribbonRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const subheadlineRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  // Auto-play entrance animation on load
  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power2.out' } });

      // Blue stage panel entrance
      tl.fromTo(
        panelRef.current,
        { opacity: 0, scale: 0.96, y: '6vh' },
        { opacity: 1, scale: 1, y: 0, duration: 0.8 },
        0
      );

      // Ribbon entrance
      tl.fromTo(
        ribbonRef.current,
        { x: '-12vw', opacity: 0 },
        { x: 0, opacity: 1, duration: 0.6 },
        0.2
      );

      // Headline entrance
      tl.fromTo(
        headlineRef.current?.querySelectorAll('.headline-line') || [],
        { y: 24, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.6, stagger: 0.08 },
        0.3
      );

      // Subheadline entrance
      tl.fromTo(
        subheadlineRef.current,
        { y: 16, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.5 },
        0.5
      );

      // CTA buttons entrance
      tl.fromTo(
        ctaRef.current?.querySelectorAll('button') || [],
        { scale: 0.92, opacity: 0 },
        { scale: 1, opacity: 1, duration: 0.5, stagger: 0.1 },
        0.6
      );

      // Cards entrance with 3D rotation
      tl.fromTo(
        cardsRef.current?.querySelectorAll('.student-card') || [],
        { x: '18vw', rotateY: -28, opacity: 0 },
        { x: 0, rotateY: -12, opacity: 1, duration: 0.7, stagger: 0.12 },
        0.4
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Scroll-driven exit animation
  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset all elements to visible when scrolling back to top
            gsap.set([panelRef.current, ribbonRef.current], { opacity: 1, x: 0, y: 0, scale: 1 });
            gsap.set(headlineRef.current?.querySelectorAll('.headline-line') || [], { opacity: 1, x: 0 });
            gsap.set(subheadlineRef.current, { opacity: 1, x: 0 });
            gsap.set(ctaRef.current?.querySelectorAll('button') || [], { opacity: 1, x: 0 });
            gsap.set(cardsRef.current?.querySelectorAll('.student-card') || [], { opacity: 1, x: 0, rotateY: -12 });
          },
        },
      });

      // ENTRANCE (0%-30%): Hold position (entrance handled by load animation)
      // SETTLE (30%-70%): Hold
      
      // EXIT (70%-100%)
      scrollTl.fromTo(
        headlineRef.current?.querySelectorAll('.headline-line') || [],
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        subheadlineRef.current,
        { x: 0, opacity: 1 },
        { x: '-14vw', opacity: 0, ease: 'power2.in' },
        0.72
      );

      scrollTl.fromTo(
        ctaRef.current?.querySelectorAll('button') || [],
        { x: 0, opacity: 1 },
        { x: '-12vw', opacity: 0, ease: 'power2.in' },
        0.74
      );

      scrollTl.fromTo(
        cardsRef.current?.querySelectorAll('.student-card') || [],
        { x: 0, rotateY: -12, opacity: 1 },
        { x: '18vw', rotateY: -28, opacity: 0, ease: 'power2.in', stagger: 0.02 },
        0.7
      );

      scrollTl.fromTo(
        ribbonRef.current,
        { y: 0, opacity: 1 },
        { y: '-10vh', opacity: 0, ease: 'power2.in' },
        0.75
      );

      scrollTl.fromTo(
        panelRef.current,
        { scale: 1, opacity: 1 },
        { scale: 1.06, opacity: 0, ease: 'power2.in' },
        0.78
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="hero"
      ref={sectionRef}
      className="section-pinned bg-[#0B0F1C] flex items-center justify-center"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/hero_classroom_bg.jpg"
          alt="Classroom"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 dark-overlay" />
      </div>

      {/* Blue Stage Panel */}
      <div
        ref={panelRef}
        className="absolute left-[6vw] top-[12vh] w-[88vw] h-[76vh] blue-stage rounded-[34px] opacity-0"
      />

      {/* Red Ribbon */}
      <div
        ref={ribbonRef}
        className="absolute left-[10vw] top-[6vh] w-[28vw] min-w-[200px] h-[10vh] min-h-[60px] red-ribbon rounded-[14px] flex items-center px-6 opacity-0 z-10"
      >
        <span className="text-white font-semibold text-sm uppercase tracking-[0.18em]">
          Sharma Classes
        </span>
      </div>

      {/* Content Container */}
      <div className="absolute inset-0 flex items-center">
        {/* Left Content */}
        <div className="w-full lg:w-1/2 px-[11vw] z-10">
          {/* Headline */}
          <div ref={headlineRef} className="mb-6">
            <h1 className="hero-title font-extrabold text-white">
              <span className="headline-line block">Scripting</span>
              <span className="headline-line block text-gradient">Success Stories</span>
            </h1>
          </div>

          {/* Subheadline */}
          <p
            ref={subheadlineRef}
            className="text-[#B8C0E0] text-lg lg:text-xl max-w-md mb-8 opacity-0"
          >
            Excellent coaching for XI–XII, undergrad & competitive exams.
          </p>

          {/* CTA Buttons */}
          <div ref={ctaRef} className="flex flex-wrap gap-4">
            <button
              onClick={() => scrollToSection('admissions')}
              className="btn-primary flex items-center gap-2"
            >
              Enroll Now
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="btn-secondary flex items-center gap-2"
            >
              <Phone className="w-4 h-4" />
              Contact Us
            </button>
          </div>
        </div>

        {/* Right Content - 3D Cards */}
        <div
          ref={cardsRef}
          className="hidden lg:block w-1/2 h-full relative card-stage"
        >
          <div className="absolute left-[8vw] top-[18vh] w-[40vw] h-[60vh] preserve-3d">
            {/* Card 1 - Top */}
            <div
              className="student-card absolute top-0 right-[15%] w-[45%] h-[55%] rounded-[22px] overflow-hidden card-shadow opacity-0 animate-float"
              style={{ transformStyle: 'preserve-3d' }}
            >
              <img
                src="/student_card_01.jpg"
                alt="Student"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F1C]/60 to-transparent" />
            </div>

            {/* Card 2 - Middle Left */}
            <div
              className="student-card absolute top-[20%] left-[5%] w-[42%] h-[50%] rounded-[22px] overflow-hidden card-shadow opacity-0 animate-float-delayed"
              style={{ transformStyle: 'preserve-3d' }}
            >
              <img
                src="/student_card_02.jpg"
                alt="Student"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F1C]/60 to-transparent" />
            </div>

            {/* Card 3 - Bottom Right */}
            <div
              className="student-card absolute bottom-[5%] right-[10%] w-[40%] h-[48%] rounded-[22px] overflow-hidden card-shadow opacity-0 animate-float-delayed-2"
              style={{ transformStyle: 'preserve-3d' }}
            >
              <img
                src="/student_card_03.jpg"
                alt="Student"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F1C]/60 to-transparent" />
            </div>
          </div>
        </div>
      </div>

      {/* Established Badge */}
      <div className="absolute bottom-8 right-8 text-white/60 text-sm font-medium">
        Established 1998
      </div>
    </section>
  );
};

export default HeroSection;
