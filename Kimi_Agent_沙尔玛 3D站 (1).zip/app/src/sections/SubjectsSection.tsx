import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Calculator, FlaskConical, BookOpen, Atom, Beaker, Dna } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const subjects = [
  { id: 1, name: 'Maths', image: '/subject_card_maths.jpg', icon: Calculator },
  { id: 2, name: 'Science', image: '/subject_card_science.jpg', icon: FlaskConical },
  { id: 3, name: 'English', image: '/subject_card_english.jpg', icon: BookOpen },
  { id: 4, name: 'Physics', image: '/subject_card_physics.jpg', icon: Atom },
  { id: 5, name: 'Chemistry', image: '/subject_card_chemistry.jpg', icon: Beaker },
  { id: 6, name: 'Biology', image: '/subject_card_biology.jpg', icon: Dna },
];

const additionalSubjects = [
  'Accountancy', 'Economics', 'Business Studies', 
  'Computer Science', 'Social Studies', 'IT'
];

const SubjectsSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const ribbonRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        panelRef.current,
        { y: '10vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        ribbonRef.current,
        { x: '-12vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.05
      );

      scrollTl.fromTo(
        contentRef.current?.querySelectorAll('.animate-item') || [],
        { y: '8vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none', stagger: 0.03 },
        0.08
      );

      scrollTl.fromTo(
        cardsRef.current?.querySelectorAll('.subject-card-item') || [],
        { x: '18vw', rotateY: -28, opacity: 0 },
        { x: 0, rotateY: -12, opacity: 1, ease: 'none', stagger: 0.03 },
        0.1
      );

      // SETTLE (30%-70%): Hold

      // EXIT (70%-100%)
      scrollTl.fromTo(
        contentRef.current?.querySelectorAll('.animate-item') || [],
        { x: 0, opacity: 1 },
        { x: '-14vw', opacity: 0, ease: 'power2.in', stagger: 0.02 },
        0.7
      );

      scrollTl.fromTo(
        cardsRef.current?.querySelectorAll('.subject-card-item') || [],
        { x: 0, rotateY: -12, opacity: 1 },
        { x: '16vw', rotateY: -28, opacity: 0, ease: 'power2.in', stagger: 0.02 },
        0.7
      );

      scrollTl.fromTo(
        ribbonRef.current,
        { y: 0, opacity: 1 },
        { y: '-8vh', opacity: 0, ease: 'power2.in' },
        0.75
      );

      scrollTl.fromTo(
        panelRef.current,
        { scale: 1, opacity: 1 },
        { scale: 1.05, opacity: 0, ease: 'power2.in' },
        0.78
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="subjects"
      ref={sectionRef}
      className="section-pinned bg-[#0B0F1C] flex items-center justify-center"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/subjects_study_bg.jpg"
          alt="Subjects"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 dark-overlay" />
      </div>

      {/* Blue Stage Panel */}
      <div
        ref={panelRef}
        className="absolute left-[6vw] top-[10vh] w-[88vw] h-[80vh] blue-stage rounded-[34px] opacity-0"
      />

      {/* Red Ribbon */}
      <div
        ref={ribbonRef}
        className="absolute left-[10vw] top-[5vh] w-[26vw] min-w-[180px] h-[10vh] min-h-[60px] red-ribbon rounded-[14px] flex items-center px-6 opacity-0 z-10"
      >
        <span className="text-white font-semibold text-sm uppercase tracking-[0.18em]">
          Subjects
        </span>
      </div>

      {/* Content Container */}
      <div className="absolute inset-0 flex items-center">
        {/* Left Content */}
        <div ref={contentRef} className="w-full lg:w-1/2 px-[11vw] z-10">
          <h2 className="animate-item section-title font-extrabold text-white mb-4 opacity-0">
            Subjects We <span className="text-gradient">Cover</span>
          </h2>

          <p className="animate-item text-[#B8C0E0] text-lg max-w-md mb-6 opacity-0">
            Expert faculty for every topic—concept clarity, problem solving, and exam techniques.
          </p>

          {/* Additional Subjects Tags */}
          <div className="animate-item flex flex-wrap gap-2 mb-6 opacity-0">
            {additionalSubjects.map((subject) => (
              <span
                key={subject}
                className="px-3 py-1 bg-white/10 rounded-full text-white/80 text-sm border border-white/10"
              >
                {subject}
              </span>
            ))}
          </div>

          <button
            onClick={() => scrollToSection('contact')}
            className="animate-item btn-primary flex items-center gap-2 opacity-0"
          >
            See Subject Details
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Right Content - Subject Cards */}
        <div
          ref={cardsRef}
          className="hidden lg:block w-1/2 h-full relative card-stage"
        >
          <div className="absolute left-[4vw] top-[14vh] w-[42vw] h-[70vh] preserve-3d">
            <div className="grid grid-cols-3 gap-3 h-full">
              {subjects.map((subject, index) => {
                const Icon = subject.icon;
                const floatClass = index % 3 === 0 
                  ? 'animate-float' 
                  : index % 3 === 1 
                    ? 'animate-float-delayed' 
                    : 'animate-float-delayed-2';
                
                return (
                  <div
                    key={subject.id}
                    className={`subject-card-item relative rounded-[22px] overflow-hidden card-shadow opacity-0 cursor-pointer group ${floatClass}`}
                    style={{ transformStyle: 'preserve-3d' }}
                  >
                    <img
                      src={subject.image}
                      alt={subject.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F1C] via-[#0B0F1C]/40 to-transparent" />
                    
                    {/* Card Content */}
                    <div className="absolute bottom-0 left-0 right-0 p-4">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 bg-[#E11D2E] rounded-lg flex items-center justify-center transition-transform group-hover:scale-110">
                          <Icon className="w-3.5 h-3.5 text-white" />
                        </div>
                        <h3 className="text-white font-bold text-sm">{subject.name}</h3>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Mobile Cards */}
        <div className="lg:hidden absolute bottom-8 left-0 right-0 px-6">
          <div className="flex gap-3 overflow-x-auto pb-4">
            {subjects.map((subject) => {
              const Icon = subject.icon;
              return (
                <div
                  key={subject.id}
                  className="flex-shrink-0 w-32 h-40 rounded-[16px] overflow-hidden card-shadow relative"
                >
                  <img
                    src={subject.image}
                    alt={subject.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F1C] via-[#0B0F1C]/50 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-3">
                    <div className="flex items-center gap-1.5">
                      <div className="w-6 h-6 bg-[#E11D2E] rounded-md flex items-center justify-center">
                        <Icon className="w-3 h-3 text-white" />
                      </div>
                      <h3 className="text-white font-bold text-xs">{subject.name}</h3>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SubjectsSection;
