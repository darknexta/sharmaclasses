import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MapPin, Phone, Mail, Send, User, MessageSquare, Clock } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

gsap.registerPlugin(ScrollTrigger);

const addresses = [
  {
    id: 1,
    title: 'Shastri Nagar',
    address: 'E-82, Near PNB, Opp. Metro Pillar No: 174, Shastri Nagar, Delhi – 110052',
    mapUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3499.995576488759!2d77.1809!3d28.6695!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjjCsDQwJzEwLjIiTiA3N8KwMTAnNTEuMiJF!5e0!3m2!1sen!2sin!4v1600000000000!5m2!1sen!2sin',
  },
  {
    id: 2,
    title: 'Kishan Ganj',
    address: '19, Rama Park, Near Jaipur Golden Transport, Above Akash Dairy, Kishan Ganj, Delhi – 110007',
    mapUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3499.5!2d77.2!3d28.66!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjjCsDM5JzM2LjAiTiA3N8KwMTInMDAuMCJF!5e0!3m2!1sen!2sin!4v1600000000000!5m2!1sen!2sin',
  },
];

const phoneNumbers = [
  { label: 'Sharma Sir', number: '9968294774' },
  { label: 'Jitender Tiwari Sir', number: '7982435981' },
  { label: 'WhatsApp', number: '9971464327' },
];

const ContactSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const leftRef = useRef<HTMLDivElement>(null);
  const rightRef = useRef<HTMLDivElement>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });
  const [showDialog, setShowDialog] = useState(false);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // Left column animation
      gsap.fromTo(
        leftRef.current,
        { x: '-6vw', opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Right column animation
      gsap.fromTo(
        rightRef.current,
        { x: '6vw', opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Form fields stagger
      gsap.fromTo(
        leftRef.current?.querySelectorAll('.form-field') || [],
        { y: 16, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.5,
          stagger: 0.06,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowDialog(true);
    setFormData({ name: '', email: '', phone: '', message: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="relative bg-[#F4F6FF] py-20 lg:py-28"
    >
      {/* Decorative diagonal shape */}
      <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-bl from-[#1E3A8A]/10 to-transparent pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-6 lg:px-12">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="section-title font-extrabold text-[#0B0F1C] mb-4">
            Get in <span className="text-[#E11D2E]">Touch</span>
          </h2>
          <p className="text-[#4A5570] text-lg max-w-2xl mx-auto">
            Visit us, call, or send a message. We're here to help you choose the right path.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Left Column - Contact Info & Form */}
          <div ref={leftRef} className="space-y-8">
            {/* Contact Info Cards */}
            <div className="grid sm:grid-cols-2 gap-4">
              {/* Addresses */}
              {addresses.map((addr) => (
                <div
                  key={addr.id}
                  className="bg-white rounded-2xl p-5 shadow-lg border border-gray-100"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 bg-[#E11D2E]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                      <MapPin className="w-5 h-5 text-[#E11D2E]" />
                    </div>
                    <div>
                      <h4 className="font-bold text-[#0B0F1C] mb-1">{addr.title}</h4>
                      <p className="text-[#4A5570] text-sm leading-relaxed">{addr.address}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Phone Numbers */}
            <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
              <h4 className="font-bold text-[#0B0F1C] mb-4 flex items-center gap-2">
                <Phone className="w-5 h-5 text-[#E11D2E]" />
                Contact Numbers
              </h4>
              <div className="space-y-3">
                {phoneNumbers.map((phone) => (
                  <a
                    key={phone.label}
                    href={`tel:${phone.number}`}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-xl hover:bg-[#E11D2E]/5 transition-colors group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-[#E11D2E] rounded-lg flex items-center justify-center">
                        <Phone className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <p className="text-[#0B0F1C] font-medium">{phone.number}</p>
                        <p className="text-[#4A5570] text-xs">{phone.label}</p>
                      </div>
                    </div>
                    <span className="text-[#E11D2E] text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                      Call
                    </span>
                  </a>
                ))}
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
              <h4 className="font-bold text-[#0B0F1C] mb-4 flex items-center gap-2">
                <Mail className="w-5 h-5 text-[#E11D2E]" />
                Send Message
              </h4>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="form-field">
                  <label className="text-[#4A5570] text-sm mb-1.5 flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Name
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-[#0B0F1C] placeholder-gray-400 focus:ring-2 focus:ring-[#E11D2E]/50 focus:border-[#E11D2E] transition-all"
                    placeholder="Your name"
                  />
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="form-field">
                    <label className="text-[#4A5570] text-sm mb-1.5 flex items-center gap-2">
                      <Mail className="w-4 h-4" />
                      Email
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-[#0B0F1C] placeholder-gray-400 focus:ring-2 focus:ring-[#E11D2E]/50 focus:border-[#E11D2E] transition-all"
                      placeholder="your@email.com"
                    />
                  </div>
                  <div className="form-field">
                    <label className="text-[#4A5570] text-sm mb-1.5 flex items-center gap-2">
                      <Phone className="w-4 h-4" />
                      Phone
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-[#0B0F1C] placeholder-gray-400 focus:ring-2 focus:ring-[#E11D2E]/50 focus:border-[#E11D2E] transition-all"
                      placeholder="+91XXXXXXXXXX"
                    />
                  </div>
                </div>

                <div className="form-field">
                  <label className="text-[#4A5570] text-sm mb-1.5 flex items-center gap-2">
                    <MessageSquare className="w-4 h-4" />
                    Message
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={3}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-[#0B0F1C] placeholder-gray-400 focus:ring-2 focus:ring-[#E11D2E]/50 focus:border-[#E11D2E] transition-all resize-none"
                    placeholder="Your message..."
                  />
                </div>

                <button
                  type="submit"
                  className="form-field w-full bg-[#E11D2E] text-white px-6 py-3 rounded-lg font-semibold flex items-center justify-center gap-2 hover:bg-[#c41828] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg"
                >
                  <Send className="w-4 h-4" />
                  Send Message
                </button>
              </form>
            </div>
          </div>

          {/* Right Column - Maps */}
          <div ref={rightRef} className="space-y-6">
            {addresses.map((addr) => (
              <div key={addr.id} className="bg-white rounded-2xl overflow-hidden shadow-lg border border-gray-100">
                <div className="p-4 border-b border-gray-100">
                  <h4 className="font-bold text-[#0B0F1C] flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-[#E11D2E]" />
                    {addr.title} Center
                  </h4>
                </div>
                <div className="h-64 bg-gray-100">
                  <iframe
                    src={addr.mapUrl}
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    title={`${addr.title} Location`}
                  />
                </div>
              </div>
            ))}

            {/* Working Hours */}
            <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
              <h4 className="font-bold text-[#0B0F1C] mb-4 flex items-center gap-2">
                <Clock className="w-5 h-5 text-[#E11D2E]" />
                Working Hours
              </h4>
              <div className="space-y-2">
                <div className="flex justify-between items-center py-2 border-b border-gray-100">
                  <span className="text-[#4A5570]">Monday - Saturday</span>
                  <span className="text-[#0B0F1C] font-medium">8:00 AM - 8:00 PM</span>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-[#4A5570]">Sunday</span>
                  <span className="text-[#E11D2E] font-medium">Closed</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Success Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="bg-white border-gray-200 text-[#0B0F1C]">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-[#E11D2E]">
              Message Sent!
            </DialogTitle>
            <DialogDescription className="text-[#4A5570]">
              Thank you for reaching out. We'll get back to you within 24 hours.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4">
            <button
              onClick={() => setShowDialog(false)}
              className="w-full bg-[#E11D2E] text-white px-6 py-3 rounded-lg font-semibold hover:bg-[#c41828] transition-colors"
            >
              Close
            </button>
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default ContactSection;
