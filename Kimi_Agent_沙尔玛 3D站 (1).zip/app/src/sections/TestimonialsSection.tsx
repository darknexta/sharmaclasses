import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Quote, Star } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const testimonials = [
  {
    id: 1,
    name: 'Priya Sharma',
    role: 'XI-XII Student',
    quote: 'The faculty made concepts feel simple. My confidence improved within weeks.',
    rating: 5,
  },
  {
    id: 2,
    name: 'Rah Kumar',
    role: 'Medical Aspirant',
    quote: 'Regular tests and feedback kept me on track. Worth every bit of effort.',
    rating: 5,
  },
  {
    id: 3,
    name: 'Ankit Patel',
    role: 'Engineering Student',
    quote: 'I finally understood how to study smart, not just hard.',
    rating: 5,
  },
];

const TestimonialsSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const ribbonRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        panelRef.current,
        { scale: 0.94, opacity: 0 },
        { scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        ribbonRef.current,
        { x: '-12vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.05
      );

      scrollTl.fromTo(
        contentRef.current?.querySelectorAll('.animate-item') || [],
        { y: '6vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none', stagger: 0.03 },
        0.08
      );

      scrollTl.fromTo(
        cardsRef.current?.querySelectorAll('.testimonial-card') || [],
        { x: '18vw', rotateY: -24, opacity: 0 },
        { x: 0, rotateY: -12, opacity: 1, ease: 'none', stagger: 0.05 },
        0.1
      );

      // SETTLE (30%-70%): Hold

      // EXIT (70%-100%)
      scrollTl.fromTo(
        contentRef.current?.querySelectorAll('.animate-item') || [],
        { x: 0, opacity: 1 },
        { x: '-14vw', opacity: 0, ease: 'power2.in', stagger: 0.02 },
        0.7
      );

      scrollTl.fromTo(
        cardsRef.current?.querySelectorAll('.testimonial-card') || [],
        { x: 0, rotateY: -12, opacity: 1 },
        { x: '16vw', rotateY: -24, opacity: 0, ease: 'power2.in', stagger: 0.03 },
        0.7
      );

      scrollTl.fromTo(
        ribbonRef.current,
        { y: 0, opacity: 1 },
        { y: '-8vh', opacity: 0, ease: 'power2.in' },
        0.75
      );

      scrollTl.fromTo(
        panelRef.current,
        { scale: 1, opacity: 1 },
        { scale: 1.05, opacity: 0, ease: 'power2.in' },
        0.78
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="testimonials"
      ref={sectionRef}
      className="section-pinned bg-[#0B0F1C] flex items-center justify-center"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/testimonials_bg.jpg"
          alt="Testimonials"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 dark-overlay" />
      </div>

      {/* Blue Stage Panel */}
      <div
        ref={panelRef}
        className="absolute left-[6vw] top-[12vh] w-[88vw] h-[76vh] blue-stage rounded-[34px] opacity-0"
      />

      {/* Red Ribbon */}
      <div
        ref={ribbonRef}
        className="absolute left-[10vw] top-[6vh] w-[32vw] min-w-[220px] h-[10vh] min-h-[60px] red-ribbon rounded-[14px] flex items-center px-6 opacity-0 z-10"
      >
        <span className="text-white font-semibold text-sm uppercase tracking-[0.18em]">
          Testimonials
        </span>
      </div>

      {/* Content Container */}
      <div className="absolute inset-0 flex items-center">
        {/* Left Content */}
        <div ref={contentRef} className="w-full lg:w-1/2 px-[11vw] z-10">
          <h2 className="animate-item section-title font-extrabold text-white mb-4 opacity-0">
            What Students <span className="text-gradient">Say</span>
          </h2>

          <p className="animate-item text-[#B8C0E0] text-lg max-w-md mb-8 opacity-0">
            Hear from the people who've been where you are—and came out stronger.
          </p>

          <button
            onClick={() => scrollToSection('contact')}
            className="animate-item btn-primary flex items-center gap-2 opacity-0"
          >
            Read More Stories
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Right Content - Testimonial Cards */}
        <div
          ref={cardsRef}
          className="hidden lg:block w-1/2 h-full relative card-stage"
        >
          <div className="absolute left-[4vw] top-[16vh] w-[42vw] h-[64vh] preserve-3d">
            <div className="grid grid-cols-2 gap-4 h-full">
              {/* Large Card - Top Left */}
              <div
                className="testimonial-card col-span-1 row-span-1 bg-[#0B0F1C]/70 backdrop-blur-sm rounded-[22px] border border-white/10 p-6 card-shadow opacity-0 animate-float flex flex-col justify-between"
                style={{ transformStyle: 'preserve-3d' }}
              >
                <div>
                  <Quote className="w-8 h-8 text-[#E11D2E] mb-4" />
                  <p className="text-white text-lg font-medium leading-relaxed mb-4">
                    "{testimonials[0].quote}"
                  </p>
                </div>
                <div>
                  <div className="flex gap-1 mb-2">
                    {[...Array(testimonials[0].rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-[#E11D2E] text-[#E11D2E]" />
                    ))}
                  </div>
                  <h4 className="text-white font-bold">{testimonials[0].name}</h4>
                  <p className="text-[#B8C0E0] text-sm">{testimonials[0].role}</p>
                </div>
              </div>

              {/* Card - Top Right */}
              <div
                className="testimonial-card col-span-1 row-span-1 bg-[#0B0F1C]/70 backdrop-blur-sm rounded-[22px] border border-white/10 p-6 card-shadow opacity-0 animate-float-delayed flex flex-col justify-between"
                style={{ transformStyle: 'preserve-3d' }}
              >
                <div>
                  <Quote className="w-8 h-8 text-[#E11D2E] mb-4" />
                  <p className="text-white text-base font-medium leading-relaxed mb-4">
                    "{testimonials[1].quote}"
                  </p>
                </div>
                <div>
                  <div className="flex gap-1 mb-2">
                    {[...Array(testimonials[1].rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-[#E11D2E] text-[#E11D2E]" />
                    ))}
                  </div>
                  <h4 className="text-white font-bold">{testimonials[1].name}</h4>
                  <p className="text-[#B8C0E0] text-sm">{testimonials[1].role}</p>
                </div>
              </div>

              {/* Card - Bottom Center (spanning both columns) */}
              <div
                className="testimonial-card col-span-2 row-span-1 bg-[#0B0F1C]/70 backdrop-blur-sm rounded-[22px] border border-white/10 p-6 card-shadow opacity-0 animate-float-delayed-2 flex flex-col justify-between"
                style={{ transformStyle: 'preserve-3d' }}
              >
                <div>
                  <Quote className="w-8 h-8 text-[#E11D2E] mb-4" />
                  <p className="text-white text-lg font-medium leading-relaxed mb-4">
                    "{testimonials[2].quote}"
                  </p>
                </div>
                <div>
                  <div className="flex gap-1 mb-2">
                    {[...Array(testimonials[2].rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-[#E11D2E] text-[#E11D2E]" />
                    ))}
                  </div>
                  <h4 className="text-white font-bold">{testimonials[2].name}</h4>
                  <p className="text-[#B8C0E0] text-sm">{testimonials[2].role}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile Cards */}
        <div className="lg:hidden absolute bottom-8 left-0 right-0 px-6">
          <div className="flex gap-4 overflow-x-auto pb-4">
            {testimonials.map((testimonial) => (
              <div
                key={testimonial.id}
                className="flex-shrink-0 w-72 bg-[#0B0F1C]/80 backdrop-blur-sm rounded-[16px] border border-white/10 p-5 card-shadow"
              >
                <Quote className="w-6 h-6 text-[#E11D2E] mb-3" />
                <p className="text-white text-sm font-medium leading-relaxed mb-3">
                  "{testimonial.quote}"
                </p>
                <div className="flex gap-0.5 mb-2">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-3 h-3 fill-[#E11D2E] text-[#E11D2E]" />
                  ))}
                </div>
                <h4 className="text-white font-bold text-sm">{testimonial.name}</h4>
                <p className="text-[#B8C0E0] text-xs">{testimonial.role}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
