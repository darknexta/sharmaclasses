import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, BookOpen, GraduationCap, Stethoscope, Scale } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const courses = [
  {
    id: 1,
    title: 'XI–XII Coaching',
    description: 'Comprehensive preparation for senior secondary exams',
    image: '/course_card_xi_xii.jpg',
    icon: BookOpen,
  },
  {
    id: 2,
    title: 'B.A., B.Com',
    description: 'Undergraduate degree programs',
    image: '/course_card_ba_bcom.jpg',
    icon: GraduationCap,
  },
  {
    id: 3,
    title: 'Medical / Engineering',
    description: 'Entrance exam preparation',
    image: '/course_card_med_eng.jpg',
    icon: Stethoscope,
  },
  {
    id: 4,
    title: 'Law Entrance',
    description: 'CLAT and law school prep',
    image: '/course_card_law.jpg',
    icon: Scale,
  },
];

const CoursesSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const ribbonRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        panelRef.current,
        { scale: 0.92, opacity: 0 },
        { scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        ribbonRef.current,
        { x: '-12vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.05
      );

      scrollTl.fromTo(
        contentRef.current?.querySelectorAll('.animate-item') || [],
        { y: '8vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none', stagger: 0.03 },
        0.08
      );

      scrollTl.fromTo(
        cardsRef.current?.querySelectorAll('.course-card') || [],
        { x: '18vw', rotateY: -26, opacity: 0 },
        { x: 0, rotateY: -12, opacity: 1, ease: 'none', stagger: 0.04 },
        0.1
      );

      // SETTLE (30%-70%): Hold position

      // EXIT (70%-100%)
      scrollTl.fromTo(
        contentRef.current?.querySelectorAll('.animate-item') || [],
        { x: 0, opacity: 1 },
        { x: '-14vw', opacity: 0, ease: 'power2.in', stagger: 0.02 },
        0.7
      );

      scrollTl.fromTo(
        cardsRef.current?.querySelectorAll('.course-card') || [],
        { x: 0, rotateY: -12, opacity: 1 },
        { x: '16vw', rotateY: -26, opacity: 0, ease: 'power2.in', stagger: 0.02 },
        0.7
      );

      scrollTl.fromTo(
        ribbonRef.current,
        { y: 0, opacity: 1 },
        { y: '-8vh', opacity: 0, ease: 'power2.in' },
        0.75
      );

      scrollTl.fromTo(
        panelRef.current,
        { scale: 1, opacity: 1 },
        { scale: 1.05, opacity: 0, ease: 'power2.in' },
        0.78
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="courses"
      ref={sectionRef}
      className="section-pinned bg-[#0B0F1C] flex items-center justify-center"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/courses_classroom_bg.jpg"
          alt="Courses"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 dark-overlay" />
      </div>

      {/* Blue Stage Panel */}
      <div
        ref={panelRef}
        className="absolute left-[6vw] top-[12vh] w-[88vw] h-[76vh] blue-stage rounded-[34px] opacity-0"
      />

      {/* Red Ribbon */}
      <div
        ref={ribbonRef}
        className="absolute left-[10vw] top-[6vh] w-[22vw] min-w-[180px] h-[10vh] min-h-[60px] red-ribbon rounded-[14px] flex items-center px-6 opacity-0 z-10"
      >
        <span className="text-white font-semibold text-sm uppercase tracking-[0.18em]">
          Courses
        </span>
      </div>

      {/* Content Container */}
      <div className="absolute inset-0 flex items-center">
        {/* Left Content */}
        <div ref={contentRef} className="w-full lg:w-1/2 px-[11vw] z-10">
          <h2 className="animate-item section-title font-extrabold text-white mb-4 opacity-0">
            What We <span className="text-gradient">Offer</span>
          </h2>

          <p className="animate-item text-[#B8C0E0] text-lg max-w-md mb-8 opacity-0">
            From school foundations to entrance exams—structured batches, focused material, and regular assessments.
          </p>

          <button
            onClick={() => scrollToSection('admissions')}
            className="animate-item btn-primary flex items-center gap-2 opacity-0"
          >
            Explore All Courses
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Right Content - Course Cards */}
        <div
          ref={cardsRef}
          className="hidden lg:block w-1/2 h-full relative card-stage"
        >
          <div className="absolute left-[4vw] top-[16vh] w-[42vw] h-[66vh] preserve-3d">
            <div className="grid grid-cols-2 gap-4 h-full">
              {courses.map((course, index) => {
                const Icon = course.icon;
                return (
                  <div
                    key={course.id}
                    className={`course-card relative rounded-[22px] overflow-hidden card-shadow opacity-0 cursor-pointer group ${
                      index % 2 === 0 ? 'animate-float' : 'animate-float-delayed'
                    }`}
                    style={{ transformStyle: 'preserve-3d' }}
                  >
                    <img
                      src={course.image}
                      alt={course.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F1C] via-[#0B0F1C]/50 to-transparent" />
                    
                    {/* Card Content */}
                    <div className="absolute bottom-0 left-0 right-0 p-5">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-8 h-8 bg-[#E11D2E] rounded-lg flex items-center justify-center">
                          <Icon className="w-4 h-4 text-white" />
                        </div>
                        <h3 className="text-white font-bold text-lg">{course.title}</h3>
                      </div>
                      <p className="text-[#B8C0E0] text-sm">{course.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Mobile Cards */}
        <div className="lg:hidden absolute bottom-8 left-0 right-0 px-6">
          <div className="flex gap-4 overflow-x-auto pb-4">
            {courses.map((course) => {
              const Icon = course.icon;
              return (
                <div
                  key={course.id}
                  className="flex-shrink-0 w-64 h-40 rounded-[22px] overflow-hidden card-shadow relative"
                >
                  <img
                    src={course.image}
                    alt={course.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F1C] via-[#0B0F1C]/50 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 bg-[#E11D2E] rounded-lg flex items-center justify-center">
                        <Icon className="w-3.5 h-3.5 text-white" />
                      </div>
                      <h3 className="text-white font-bold text-sm">{course.title}</h3>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default CoursesSection;
